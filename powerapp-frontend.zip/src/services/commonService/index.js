import CommonService from './commonService';

export default CommonService;
