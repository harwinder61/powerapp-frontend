import MemberService from './memberService';

export default MemberService;
