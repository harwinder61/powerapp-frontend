import AuthService from './authService';

export default AuthService;
