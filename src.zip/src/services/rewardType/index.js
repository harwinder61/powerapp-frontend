import RewardTypeService from './rewardTypeService';

export default RewardTypeService;
