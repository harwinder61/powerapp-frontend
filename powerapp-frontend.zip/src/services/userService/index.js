import UserService from './userService';

export default UserService;
