import RewardTransactionHistory from './rewardTransactionHistoryService';

export default RewardTransactionHistory;
