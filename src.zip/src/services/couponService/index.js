import CouponService from './couponService';

export default CouponService;
