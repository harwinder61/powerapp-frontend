import OfferhistoryService from './offerhistoryService';

export default OfferhistoryService;
