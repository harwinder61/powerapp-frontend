import ConsumerWalletService from './consumerWalletService';

export default ConsumerWalletService;
